<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\TeacherRequest;
use App\Models\Catogry\MainCategory;
use App\Models\Teacher;
use Illuminate\Http\Request;

class TeacherController extends Controller
{
    public function approve($id)
    {
        $teacher = Teacher::find($id);
        $teacher->approved = 1;
        $teacher->save();
        return redirect()->back()->with('success', 'Teacher Approved Successfully');
    }
    public function index()
    {
        $teachers = teacher::where('approved', 1)->get();
        return view('admin.teacher.index', compact('teachers'));
    }
    public function create()
    {
        $main_categories = MainCategory::all();
        return view('admin.teacher.create', compact('main_categories'));
    }
    public function store(TeacherRequest $request)
    {
        $file_name = '';
        if($request->hasFile('image')){
            $file_extension = $request->file('photo')->getClientOriginalExtension();
            $file_name = time() . '.' . $file_extension;
            $request->file('photo')->move('assets/images/teachers', $file_name);
        }
        $teacher = new Teacher();
        $teacher->name = $request->name;
        $teacher->email = $request->email;
        $teacher->phone = $request->phone;
        $teacher->description = $request->description;
        $teacher->sections = implode(' , ', $request->sections);


        if(!$request->has('course_access')){
            $teacher->course_access = 0;
        }else{
            $teacher->course_access = 1;
        }

        $teacher->photo = $file_name;
        $teacher->password = bcrypt($request->password);
        $teacher->approved = 1;
        $teacher->status = 1;
        $teacher->save();
        return redirect()->route('get.admin.teacher')->with('success', 'تم اضافة المعلم بنجاح');
    }
    public function edit($id)
    {
        $teacher = Teacher::find($id);
        $teacher_sections =  explode(' , ', $teacher->sections);
        $main_categories = MainCategory::all();
        return view('admin.teacher.edit', compact('teacher', 'main_categories' , 'teacher_sections'));
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:teachers,email,' . $id,
            'phone' => 'required|unique:teachers,phone,' . $id,
            'description' => 'required',
            'sections' => 'required',
        ]);
        
        $teacher = Teacher::find($id);
        $teacher->name = $request->name;
        $teacher->email = $request->email;
        $teacher->phone = $request->phone;
        $teacher->description = $request->description;
        $teacher->sections = implode(' , ', $request->sections);
        if(!$request->has('course_access')){
            $teacher->course_access = 0;
        }else{
            $teacher->course_access = 1;
        }
        if(!$request->has('status')){
            $teacher->status = 0;
        }else{
            $teacher->status = 1;
        }
        if($request->hasFile('photo')){
            unlink('assets/images/teachers/' . $teacher->photo);
            $file_extension = $request->file('photo')->getClientOriginalExtension();
            $file_name = time() . '.' . $file_extension;
            $request->file('photo')->move('assets/images/teachers', $file_name);
            $teacher->photo = $file_name;
        }
        $teacher->approved = 1;
        if(!empty($request->password)){
            $teacher->password = bcrypt($request->password);
        }
        $teacher->save();
        return redirect()->route('get.admin.teacher')->with('success', 'تم تعديل المعلم بنجاح');
    }
}
