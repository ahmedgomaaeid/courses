<?php

namespace App\Models\Catogry;

use Illuminate\Database\Eloquent\Model;

class MainCategory extends Model
{
    protected $fillable = [
        'name', 
    ];
}
